import React, { useState } from 'react';
import { Lock, Unlock, Copy, Check } from 'lucide-react';
import { EncryptionService } from '../services/encryptionService';

const encryptionService = new EncryptionService();

export function EncryptionForm() {
  const [text, setText] = useState('');
  const [password, setPassword] = useState('');
  const [result, setResult] = useState('');
  const [isEncrypted, setIsEncrypted] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleEncrypt = async () => {
    try {
      const encrypted = await encryptionService.encrypt(text, password);
      setResult(JSON.stringify(encrypted));
      setIsEncrypted(true);
    } catch (error) {
      setResult('Encryption failed: ' + error.message);
    }
  };

  const handleDecrypt = async () => {
    try {
      const encryptedData = JSON.parse(text);
      const decrypted = await encryptionService.decrypt(encryptedData, password);
      if (decrypted.success) {
        setResult(decrypted.plaintext);
        setIsEncrypted(false);
      } else {
        setResult(decrypted.error || 'Decryption failed');
      }
    } catch (error) {
      setResult('Invalid encrypted data format');
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="space-y-4">
        <textarea
          className="w-full h-32 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder={isEncrypted ? "Enter encrypted data to decrypt" : "Enter text to encrypt"}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        
        <div className="flex space-x-4">
          <input
            type="password"
            className="flex-1 p-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          
          <button
            onClick={isEncrypted ? handleDecrypt : handleEncrypt}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 flex items-center space-x-2"
          >
            {isEncrypted ? (
              <>
                <Unlock className="w-4 h-4" />
                <span>Decrypt</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>Encrypt</span>
              </>
            )}
          </button>
        </div>
      </div>

      {result && (
        <div className="mt-6 space-y-2">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Result:</h3>
            <button
              onClick={handleCopy}
              className="p-2 text-gray-600 hover:text-gray-800 focus:outline-none"
              title="Copy to clipboard"
            >
              {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
            </button>
          </div>
          <pre className="bg-gray-100 p-4 rounded-lg overflow-x-auto">
            {result}
          </pre>
        </div>
      )}
    </div>
  );
}